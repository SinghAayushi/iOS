//
//  ApodDataModel.swift
//  PictureOfTheDay
//
//  Created by Aayushi Singh on 07/02/22.
//

import Foundation
struct ApodDataModel: Decodable {
    let date, explanation: String
       let hdurl: String
       let mediaType, serviceVersion, title: String
       let url: String

       enum CodingKeys: String, CodingKey {
           case date, explanation, hdurl
           case mediaType = "media_type"
           case serviceVersion = "service_version"
           case title, url
       }
}
