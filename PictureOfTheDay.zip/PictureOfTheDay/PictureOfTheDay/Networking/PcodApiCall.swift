//
//  PcodApiCall.swift
//  PictureOfTheDay
//
//  Created by Aayushi Singh on 07/02/22.
//

import Foundation
import UIKit
protocol PcodApiCallDelegate: AnyObject {
    func apicall(_ agent: PcodApiCall, apodCallSuccess response: ApodDataModel)
    func apicall(_ agent: PcodApiCall, apodCallFailed error: String)
    func apicall(_ agent: PcodApiCall, imageCallSuccess response: UIImage)
}

class PcodApiCall {
    let url = "https://api.nasa.gov/planetary/apod"
    let dateString: String?
    let API_KEY = "5yHWWPnyfuu7OFu1iBwKqvefJvg99hFNEL2WOZCD"
    
    typealias Delegate = PcodApiCallDelegate
    weak var delegate: Delegate?
    
    init(dateString: String) {
        self.dateString = dateString
    }
    
    /**
     makeApodCall() - apod api call
     */
    func makeApodCall () {
        //url is formed with/ without date based on the user's input
        var request = URLRequest(url: formURL())
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                //if there's error in the response then the method returns
                guard let data = data, error == nil else {
                    return
                }
                
                do {
                    let jsonDecoder = JSONDecoder()
                    // fetches the data in the format of ApodDataModel
                    let jsonObject = try jsonDecoder.decode(ApodDataModel.self, from: data)
                 
                    //trigger protocol method to update ui with title and the description
                    self.delegate?.apicall(self, apodCallSuccess: jsonObject)
                    
                    // call method to load image
                    self.loadImage(imageUrl: jsonObject.url)
                } catch let parsingError {
                    print("Error", parsingError)
               }
                
            }
        }
        task.resume()
    }
    
    /**
     formURL() - url is formed with/ without date based on the user's input
     */
    func formURL() -> URL{
        if let date = dateString {
            let formedUrl = "\(url)?api_key=\(API_KEY)&date=\(date)"
            return URL(string: formedUrl)!
        }
        
        return URL(string: "\(url)?api_key=\(API_KEY)")!
    }
    
    /**
     loadImage() - after making apod api call we download the image in the background as soon as it's loaded it's shown on the UI
     */
    func loadImage(imageUrl: String) {
        guard let url = URL(string: imageUrl) else {
            return
        }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, _, _) in
            if let data = data {
                // Create Image and Update Image View
                DispatchQueue.main.async {
                    // triggers the method to indicate that the image is downloaded 
                    self.delegate?.apicall(self, imageCallSuccess: UIImage(data: data)!)
                }
                
            }
        }
        
        dataTask.resume()
    }
    

}

