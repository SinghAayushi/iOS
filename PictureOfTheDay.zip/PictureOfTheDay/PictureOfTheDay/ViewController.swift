//
//  ViewController.swift
//  PictureOfTheDay
//
//  Created by Aayushi Singh on 06/02/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var datePickerTextField: UITextField!
    @IBOutlet var podImageView: UIImageView!
    @IBOutlet var titleTextView: UILabel!
    @IBOutlet var descriptionTextView: UILabel!
    @IBOutlet var loadingIndicator: UIActivityIndicatorView!
    
    
    let datePicker = UIDatePicker()
    let toolBar = UIToolbar()
    var apiObj = PcodApiCall.init(dateString: "")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Date picker view initializer (works for all iOS versions)
        initializeDatePicker()
        callPodApi() // Makes the api call to fetch the apod
        loadingIndicator.startAnimating() // showing loading indicator until picture is loaded 
    }
    
    /**
     callPodApi - makes api call to fetch the apod details
     */
    func callPodApi(){
        apiObj.delegate = self
        apiObj.makeApodCall()
    }
    
    /**
     initializeDatePicker - date time picker - provided to user to choose a valid date and fetch the apod details
     */
    func initializeDatePicker() {
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.frame.size = CGSize(width: 0.0, height: 250.0)
        datePickerTextField.inputView = datePicker
        
        //setting toolbar style
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 92/255, green: 216/255, blue: 255/255, alpha: 1)
        toolBar.sizeToFit()

        // Adding Button ToolBar
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(ViewController.doneClick))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(ViewController.cancelClick))
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: true)
        toolBar.isUserInteractionEnabled = true
        datePickerTextField.inputAccessoryView = toolBar
    }
    
    /**
     doneClick() - picker view done button click
     */
    @objc func doneClick() {
        // if currently selected date is greater than the current date (future dates), then showing an alert view to
        // choose another date as the future dates will have nil response
        if datePicker.date > Date.now {
            showAlertDialog(title: "Invalid date", message: "The date must be today's and older!")
            return
        }
        let dateFormatter1 = DateFormatter()
        dateFormatter1.dateFormat = "yyyy-MM-dd"
    
        print(dateFormatter1.string(from: datePicker.date) )
        apiObj = PcodApiCall.init(dateString: dateFormatter1.string(from: datePicker.date))
        callPodApi()
        datePickerTextField.resignFirstResponder()
    }

    /**
     cancelClick() - closing the picker view when user clicks on cancel button
     */
    @objc func cancelClick() {
        datePickerTextField.resignFirstResponder()
    }

}

//MARK: API protocol implementation
extension ViewController : PcodApiCallDelegate {
    func apicall(_ agent: PcodApiCall, apodCallSuccess response: ApodDataModel) {
        //on a success call back of apod api setting the date, title and description, starting the loading indicator until image is loaded
        self.datePickerTextField.text = response.date
        self.titleTextView.text = response.title
        self.descriptionTextView.text = response.explanation
        loadingIndicator.isHidden = false
        self.podImageView.isHidden = true
    }
    
    func apicall(_ agent: PcodApiCall, apodCallFailed error: String) {
        showAlertDialog(title: "Reachability issue", message: "Please check your internet connection and try again!")
    }
    
    func apicall(_ agent: PcodApiCall, imageCallSuccess response: UIImage) {
        //sets the image to the imafe view and hides the indicator
        self.podImageView.image = response
        loadingIndicator.isHidden = true
        self.podImageView.isHidden = false
    }
    
}

//MARK: alert view
extension ViewController {
    // alert view to handle the errors
    func showAlertDialog(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
}





